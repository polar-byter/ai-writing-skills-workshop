# Урок 1. Маршрут "ТЗ"

Краткая памятка. Подробности и объяснения - в уроке.

1. Прочитайте source.md, facts.md и CHECKLIST.md.
2. До отправки запишите в observations.md догадку: на каком пункте CHECKLIST.md модель споткнётся.
3. Создайте New session, вставьте текст PROMPT.md и отправьте.
4. Пройдите results/answer.md по CHECKLIST.md и запишите конкретные фразы.
